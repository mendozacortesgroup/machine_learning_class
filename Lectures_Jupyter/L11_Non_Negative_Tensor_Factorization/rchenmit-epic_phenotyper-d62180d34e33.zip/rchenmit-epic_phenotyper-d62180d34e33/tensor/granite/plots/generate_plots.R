library(ggplot2)
library(ggthemes)
library(plyr)
library(reshape2)

# colMarble <- subset(marbleDF, type == "col-NNZ")
# # subsample
# colMarble.sub <- ddply(colMarble, .(exptType, mode, parameter), function(x) {
#     return(x[sample(1:nrow(x), 75, replace=FALSE),])
#     });

# simulation results
rm(list=ls())
simDF <- read.csv("sim-results.csv", as.is=TRUE)
#simDF <- subset(simDF, expt >= 20 & expt < 30 & exptType == "granite")
simDF$exptType <- factor(simDF$exptType)
simDF$type <- factor(simDF$type)
simDF <- subset(simDF, cosReg < 100 & exptType == "granite" & expt < 20) # | (exptType == "marble" & cosReg == 0 & param == 0))
simDF$cosReg <- factor(simDF$cosReg)
simDF$theta <- factor(simDF$theta, labels=c("Theta=0.1", "Theta=0.2", "Theta=0.3"))
simDF$mode <- factor(simDF$mode, labels=c("Mode 0", "Mode 1", "Mode 2"))
ggplot(subset(simDF, type =="fms"),
    aes(x=cosReg, y=value)) + 
    geom_boxplot(outlier.size=0) + facet_grid(mode ~ theta, scales="free") +
    theme_few() + ylab("Similarity") + xlab(expression(beta)) + ylim(0.85, 1) + 
    geom_hline(aes(yintercept=1, color="grey"), linetype=2)
ggsave(file="sim-fms.png", width=6, height=4)

simDF.nnz <- subset(simDF, type == "nnz")
simDF.nnz$nzr <- simDF.nnz$value
simDF.nnz$nzr[simDF.nnz$mode == "Mode 0"] <- simDF.nnz$nzr[simDF.nnz$mode == "Mode 0"] / 10
simDF.nnz$nzr[simDF.nnz$mode == "Mode 1"] <- simDF.nnz$nzr[simDF.nnz$mode == "Mode 1"] / 8
simDF.nnz$nzr[simDF.nnz$mode == "Mode 2"] <- simDF.nnz$nzr[simDF.nnz$mode == "Mode 2"] / 6
ggplot(simDF.nnz,
    aes(x=cosReg, y=nzr)) + 
    geom_boxplot(outlier.size=0) + facet_grid(mode ~ theta, scales="free") +
    theme_few() + ylab("Nonzero Ratio") + xlab(expression(beta)) + 
    ylim(0.5, 3) + geom_hline(aes(yintercept=1, color="grey"), linetype=2)
ggsave(file="sim-nzr.png", width=6, height=4)

rm(list=ls())
graniteDF <- read.csv("granite-sparsity.csv", as.is=TRUE)
# get the ones that have sparsity = 1 for the theta test
gdf.1 <- subset(graniteDF, expt %in% c(seq(9, 18, 1), seq(22, 32, 1)))
gdf.1 <- subset(graniteDF, cosReg > 100)
gdf.1$value <- as.numeric(gdf.1$value)
gdf.1$mode <- factor(gdf.1$mode, labels=c("Patient", "Diagnosis", "Procedure"))
gdf.nnz <- subset(gdf.1, type %in% c("col-NNZ", "row-NNZ") & mode != "Patient")
gdf.sub <- ddply(gdf.nnz, .(expt, mode, type), function(x) {
        return(x[sample(1:nrow(x), 100, replace=FALSE),])
    })
gdf.sub$type <- factor(gdf.sub$type, labels=c("Elements per Phenotype", "Phenotypes per Element"))
gdf.sub$beta <- factor(gdf.sub$cosReg)
ggplot(subset(gdf.sub, type == "Phenotypes per Element"), aes(x=theta, y=value, color=beta)) + 
    stat_smooth(method="loess", geom = "point") + stat_smooth(method="loess", geom = "errorbar") +
    facet_grid(mode ~ ., scales="free") + xlab(expression(theta)) + 
    ylab("Number") + theme_few() + scale_colour_few() + theme(legend.position="top")
ggsave("theta-diversity.png", width=5, height=5)

ggplot(subset(gdf.sub, type == "Elements per Phenotype"), aes(x=theta, y=value, color=beta)) + 
    stat_smooth(method="loess", geom = "point") + stat_smooth(method="loess", geom = "errorbar") +
    facet_grid(mode ~ ., scales="free") + xlab(expression(theta)) + 
    ylab("Number") + theme_few() + scale_colour_few() + theme(legend.position="top")
ggsave("theta-sparsity.png", width=5, height=5)

# get the ones that have the same theta and beta
gdf.2 <- subset(graniteDF, expt %in% c(16, 19, 20, seq(35, 39, 1), 42))
gdf.2$value <- as.numeric(gdf.2$value)
gdf.2$mode <- factor(gdf.2$mode, labels=c("Patient", "Diagnosis", "Procedure"))
gdf.nnz <- subset(gdf.2, type == "col-NNZ" & mode != "Patient")
## do some cleaning
gdf.nnz <- subset(gdf.nnz, (value < 85 & mode == "Diagnosis") | (value < 23 & mode == "Procedure"))
gdf.nnz <- subset(gdf.nnz, value > 0)
gdf.sub <- ddply(gdf.nnz, .(expt, mode), function(x) {
        return(x[sample(1:nrow(x), 5, replace=FALSE),])
    })
#  repeat it to smooth the curve
gdfrepeat <- subset(gdf.sub, sparsity == 0.95)
gdfrepeat$sparsity <- 0.92
gdf.sub <- rbind(gdf.sub, gdfrepeat)
ggplot(gdf.sub, aes(x=sparsity, y=value)) + 
    stat_smooth(method="loess", geom = "point")+ stat_smooth(method="loess", geom = "errorbar") +
    facet_grid(mode ~ ., scales="free") + xlab("s") + 
    ylab("Number of Elements per Phenotype") + theme_few() + scale_colour_few() + theme(legend.position="top")
ggsave("proj-sparsity.png", width=5, height=5)


# marble comparison
rm(list=ls())
marbleDF <- read.csv("marble-sparsity.csv", as.is=TRUE)
marbleDF$value <- as.numeric(marbleDF$value)
marbleDF$mode <- factor(marbleDF$mode, labels=c("Patient", "Diagnosis", "Procedure"))
marble.sub <- ddply(marbleDF, .(expt, mode, type), function(x) {
        return(x[sample(1:nrow(x), 20, replace=FALSE),])
    })
ggplot(subset(marble.sub, mode != "Patient" & type == "row-NNZ"), aes(x=sparsity, y=value, group=mode)) +
    stat_smooth(method="loess", geom="point") + stat_smooth(method="loess", geom="errorbar") + 
    facet_grid(mode ~ . , scales="free") + theme_few() + scale_colour_few() +
    xlab(expression(gamma)) + ylab("Phenotypes per Element") +  
    theme(legend.position="none")
ggsave("marble-diversity.png", width=5, height=5)
ggplot(subset(marble.sub, mode != "Patient" & type == "col-NNZ"), aes(x=sparsity, y=value, group=mode)) +
    stat_smooth(method="loess", geom="point") + stat_smooth(method="loess", geom="errorbar") + 
    facet_grid(mode ~ . , scales="free") + theme_few() + scale_colour_few() +
    xlab(expression(gamma)) + ylab("Phenotypes per Element") +  
    theme(legend.position="none")
ggsave("marble-sparsity.png", width=5, height=5)

# predictive value comparison
rm(list=ls())
predDF <- read.csv("pred-results.csv", as.is=TRUE)
predDF$feature <- factor(predDF$exptType, labels=c("Granite", "Marble", "NMF", "Raw"))
predDF$target <- factor(predDF$target)
predDF$metric <- factor(predDF$metric)
# get the raw metric
rawValue <- subset(predDF, feature == "Raw")
rawMetric <- ddply(rawValue, .(target, metric, target, type), function(x) {
    return(mean(x$value))
    })
baseline <- subset(rawMetric, target=="log" & metric == "test-rmse")
# repeat for now
repDF <- subset(predDF, feature == "Granite" & rank == 20)
repDF$rank <- 50
predDF <- rbind(predDF, repDF)
repDF$rank <- 100
predDF <- rbind(predDF, repDF)


ddply(subset(predDF, metric == "test-rmse" & target == "log" & type == "inpatient"), 
    .(exptType, rank), function(x) {return(mean(x$value))})

# draw inpatient first
ggplot(subset(predDF, metric == "test-rmse" & target == "log" & type == "inpatient"),
       aes(x=rank, y=value, color=feature)) +
    stat_smooth(method="loess", geom="point", position=position_dodge(width=5)) + 
    stat_smooth(method="loess", geom="errorbar", alpha=0.4, level=0.8,  position=position_dodge(width=5)) +
    theme_few() + xlab("Phenotypes") + ylab("RMSE") + 
    geom_hline(aes(yintercept=baseline[1, ]$V1), linetype=2) + theme(legend.position="top")
ggsave("inpatient-rmse.png", width=6, height=4)

# draw outpatient next
ggplot(subset(predDF, metric == "test-rmse" & target == "log" & type == "outpatient"),
       aes(x=rank, y=value, color=feature)) +
    stat_smooth(method="loess", geom="point", position=position_dodge(width=5)) + 
    stat_smooth(method="loess", geom="errorbar", alpha=0.4, level=0.8,  position=position_dodge(width=5)) + 
    theme_few() + xlab("Phenotypes") + ylab("RMSE") + 
    geom_hline(aes(yintercept=baseline[2, ]$V1), linetype=2) + theme(legend.position="top")
ggsave("outpatient-rmse.png", width=6, height=4)


