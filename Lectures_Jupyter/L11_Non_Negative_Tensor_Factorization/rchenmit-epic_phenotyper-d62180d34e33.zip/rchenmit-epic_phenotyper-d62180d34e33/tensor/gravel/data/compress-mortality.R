library(plyr)
library(reshape2)

## get the demographic information
basic <- read.csv("mort-stays.csv")
## fix the class information
basic$class <- 0
basic$class[basic$mortality=='t'] <- 1
basic$age_bin1 <- (basic$age <= 34) * 1
basic$age_bin2 <- (basic$age > 34 & basic$age <= 50) * 1
basic$age_bin3 <- (basic$age > 50 & basic$age <= 65) * 1
basic$age_bin4 <- (basic$age > 65 & basic$age <= 80) * 1
basic$age_bin5 <- (basic$age > 80) * 1
basic$gender_M <- (basic$gender == "M") * 1
basic$gender_F <- (basic$gender == "F") * 1
basic$icutype_CCU <- (basic$icutype == "CCU") * 1
basic$icutype_CSRU <- (basic$icutype == "CSRU") * 1
basic$icutype_FICU <- (basic$icutype == "FICU") * 1
basic$icutype_MICU <- (basic$icutype == "MICU") * 1
basic$icutype_SICU <- (basic$icutype == "SICU") * 1
basic <- subset(basic, select=-c(age,gender,icutype,mortality))
write.csv(basic, file="mort-basic.csv")

### Deal with the lab values
countRange <- function(x, lower, upper) {
	x <- subset(x, !is.na(value)) 
	nmx <- sum(x$value <= upper & x$value >= lower)	
	abx <- nrow(x) - nmx
	return (data.frame(meas=toupper(x$variable[1]),normal=nmx, abnormal=abx))
}

singleMeasurement <- function(variable, lb, ub) {
	f <- read.csv(sprintf('mort-%s.csv', variable), header=TRUE)
	meltf <- melt(f, id=c("subject_id", "time"))
	return(ddply(meltf, .(subject_id), countRange, lower=lb, upper=ub))
}

singleLabMeasurement <- function(variable) {
	f <- read.csv(sprintf('mort-%s.csv', variable), header=TRUE)
	meas = toupper(variable)
	f <- subset(f, id=c("subject_id", "time", "flag"))
	# count abnormal, count normal
	return(ddply(f, .(subject_id), function(x) {
			nmx <- sum(x$flag == 'normal')
			abx <- nrow(x) - nmx
			return(data.frame(meas=meas,normal=nmx, abnormal=abx))
		}))
}

## blood pressure counting
bp <- read.csv('mort-bp.csv', header=TRUE)
melt.bp <- melt(bp, id=c("subject_id", "time"))
sbp <- subset(melt.bp, variable=='systolic')
results <- ddply(sbp, .(subject_id), countRange, lower=0, upper=139)
dbp <- subset(melt.bp, variable=='diastolic')
results <- rbind(results, ddply(dbp, .(subject_id), countRange, lower=0, upper=89))

results <- rbind(results, singleMeasurement("hr", 60, 100))		## heart rate 
results <- rbind(results, singleMeasurement("rr", 60, 100))		## respiratory rate 
results <- rbind(results, singleMeasurement("sao2", 60, 100))	## oxygen saturation
results <- rbind(results, singleMeasurement("temp", 60, 100))	## temperature 
results <- rbind(results, singleMeasurement("mbp", 60, 100))	## mean arterial pressure
results <- rbind(results, singleMeasurement("gcs", 60, 100))	## gcs scores 
results <- rbind(results, singleMeasurement("aph", 7.35, 7.45))	## arterial ph 
results <- rbind(results, singleMeasurement("paco2", 35, 45))	## PaCO2 

results <- rbind(results, singleLabMeasurement("albumin"))		## albumin
results <- rbind(results, singleLabMeasurement("alp"))			## ALP
results <- rbind(results, singleLabMeasurement("alt"))			## ALT
results <- rbind(results, singleLabMeasurement("ast"))			## AST
results <- rbind(results, singleLabMeasurement("bilirubin"))	## bilirubin
results <- rbind(results, singleLabMeasurement("bun"))			## BUN
results <- rbind(results, singleLabMeasurement("cholesterol"))	## cholesterol
results <- rbind(results, singleLabMeasurement("creatinine"))	## creatinine
results <- rbind(results, singleLabMeasurement("glucose"))		## glucose
results <- rbind(results, singleLabMeasurement("hco3"))			## HCO3
results <- rbind(results, singleLabMeasurement("hct"))			## Hematocrit
results <- rbind(results, singleLabMeasurement("k"))			## serum potassium
results <- rbind(results, singleLabMeasurement("lactate"))		## Lactate
results <- rbind(results, singleLabMeasurement("mg"))			## Magnesium
results <- rbind(results, singleLabMeasurement("na"))			## Sodium
results <- rbind(results, singleLabMeasurement("tropi"))		## Troponin-I 
results <- rbind(results, singleLabMeasurement("tropt"))		## Troponin-T

results <- melt(results, id=c("subject_id", "meas"))
results <- subset(results, value > 0) ## remove the ones with 0s
results <- results[order(results$subject_id), ]
write.table(results, file="mort-physio.csv", sep=",", row.names=FALSE, col.names=FALSE)

